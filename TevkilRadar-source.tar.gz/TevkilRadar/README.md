# Tevkil Radarı · Android

Ankara'daki tevkil ilanlarına odaklı, cihazda çalışan Android uygulaması (ilk test sürümü).

## Neler çalışır?

- Kullanıcı izin verdikten sonra WhatsApp, WhatsApp Business, Telegram ve Instagram **telefon bildirimlerinde görünen metinlerden** ilan yakalama.
- Ankara ve ilçeleri için Türkçe karakterlere duyarlı eşleştirme.
- Dahil/hariç kelimeler, isteğe bağlı ilçe listesi, minimum ilan ücreti.
- Yeni ilan bildirimi, yerel SQLite kayıt, mükerrer ilan engelleme.
- Kullanıcının kendisinin seçtiği ilana verdiği onayla, uygulama sunuyorsa bildirimden doğrudan yanıt; yoksa Android paylaş menüsü.
- Diğer uygulamaların **Paylaş → Tevkil Radarı** seçeneğiyle manuel ilan/bağlantı içe aktarma.
- Kişiselleştirilebilir cevap şablonu, örnek ilan, kayıtları silme.

## Kurulum

GitHub Actions `Android APK - Tevkil Radari` iş akışında oluşan `TevkilRadari-debug-apk` dosyasını indirip açın; içindeki `app-debug.apk` dosyasını Android cihaza kurun. Yerel derlemek için Android SDK 35 ve Java 17 ile `gradle :app:assembleDebug` kullanın.

Uygulamada **Bildirim erişimi ver** düğmesine dokunun ve Tevkil Radarı'na bildirim erişimi izni verin. Android 13+ sistemlerde bildirim gönderme iznini de onaylayın. İsterseniz **Örneği dene** ile filtreleri sınayın.

## Sınırlar ve gizlilik

Bu sürüm Instagram/WhatsApp/Telegram'ın tüm uzak içeriğine **erişmez**, geçmiş mesajları toplu taramaz ve platform API'lerinin sağlamadığı mesajlara erişemez. Yalnızca telefonda erişime izin verilen, bildirimlerde görünen içerikleri işleyebilir. Sessize alınan gruplar veya bildirimi görünmeyen mesajlar kaçırılabilir. Otomatik başvuru yoktur; kullanıcı belirli ilan için onay verir. Ücret belirtilmeyen ilanlar, ücret filtresi sıfırdan büyükse elenir. Doğrudan yanıt gönderimi başarısız olabilir; uygulama yalnızca bildirim yanıt işleminin başlatıldığını bildirir.

Tüm veriler cihazın uygulama veritabanında kalır. Uygulama INTERNET izni istemez, hesap şifresi toplamaz, sunucuya veri göndermez. Bu durum sunucudan 7/24 tarama yapılmadığı anlamına gelir. Hesap bağlantıları veya açık API entegrasyonları sonraki sürümlere aittir.

Bu bir avukatlar arası iş ilanı takip aracıdır; hukuki tavsiye vermez ve mesleki kurallara uyma sorumluluğunu ortadan kaldırmaz.
