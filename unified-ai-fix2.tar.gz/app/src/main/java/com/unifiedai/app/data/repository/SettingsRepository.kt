package com.unifiedai.app.data.repository

import com.unifiedai.app.core.model.ChatMode
import kotlinx.coroutines.flow.Flow

data class ProviderPolicy(
    val enabled: Boolean = false,
    val dailyRequestLimit: Int = 25,
    val allowInCouncil: Boolean = false,
)

data class AppSettings(
    val ollamaUrl: String = "",
    val defaultMode: ChatMode = ChatMode.SMART,
    val historyEnabled: Boolean = true,
    val memoryEnabled: Boolean = false,
    val cloudAllowed: Boolean = true,
    val gemini: ProviderPolicy = ProviderPolicy(),
    val openAi: ProviderPolicy = ProviderPolicy(),
    val anthropic: ProviderPolicy = ProviderPolicy(),
    val deepSeek: ProviderPolicy = ProviderPolicy(),
)

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun current(): AppSettings
    suspend fun setOllamaUrl(url: String)
    suspend fun setDefaultMode(mode: ChatMode)
    suspend fun setHistoryEnabled(enabled: Boolean)
    suspend fun setMemoryEnabled(enabled: Boolean)
    suspend fun setCloudAllowed(enabled: Boolean)
    suspend fun setProviderPolicy(providerId: String, policy: ProviderPolicy)
}
