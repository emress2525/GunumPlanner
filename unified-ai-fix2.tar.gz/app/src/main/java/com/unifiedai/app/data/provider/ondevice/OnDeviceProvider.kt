package com.unifiedai.app.data.provider.ondevice

import com.unifiedai.app.core.model.*
import com.unifiedai.app.domain.provider.AiProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

interface OnDeviceRuntime {
    val ready: Boolean
    suspend fun generate(prompt: String): String
    fun stream(prompt: String): Flow<String>
    suspend fun cancel()
}

class OnDeviceProvider(private val runtime: OnDeviceRuntime) : AiProvider {
    override val providerId: String = "ondevice"
    override val displayName: String = "Telefon Yerel AI"
    override val isLocalProvider: Boolean = true

    private val descriptor = ModelDescriptor(
        providerId = providerId,
        modelId = "gemma-4-e2b",
        displayName = "Gemma 4 E2B • cihazda",
        capabilities = setOf(
            ModelCapability.CHAT,
            ModelCapability.REASONING,
            ModelCapability.CODING,
            ModelCapability.VISION,
            ModelCapability.LONG_CONTEXT,
        ),
        isLocal = true,
        latencyClass = LatencyClass.MEDIUM,
        privacyClass = 3,
    )

    override suspend fun healthCheck(): ProviderHealth =
        if (runtime.ready) ProviderHealth.Healthy else ProviderHealth.Unhealthy("Telefon içi model henüz indirilmedi")

    override suspend fun listModels(): List<ModelDescriptor> = if (runtime.ready) listOf(descriptor) else emptyList()

    override suspend fun generate(request: ChatRequest, model: ModelDescriptor): ChatResponse {
        require(runtime.ready) { "Telefon içi model henüz indirilmedi" }
        val started = System.currentTimeMillis()
        val text = runtime.generate(buildPrompt(request))
        return ChatResponse(
            requestId = request.requestId,
            text = text,
            providerId = providerId,
            modelId = model.modelId,
            completed = true,
            latencyMs = System.currentTimeMillis() - started,
        )
    }

    override fun stream(request: ChatRequest, model: ModelDescriptor): Flow<ChatChunk> = flow {
        require(runtime.ready) { "Telefon içi model henüz indirilmedi" }
        var emitted = false
        runtime.stream(buildPrompt(request)).collect { delta ->
            if (delta.isNotEmpty()) {
                emitted = true
                emit(ChatChunk(request.requestId, delta, false))
            }
        }
        emit(ChatChunk(request.requestId, "", true))
    }

    override suspend fun cancel(requestId: String) = runtime.cancel()

    private fun buildPrompt(request: ChatRequest): String = buildString {
        appendLine("Sen Birleşik AI adlı yardımcı asistansın. Türkçe sorulara Türkçe cevap ver. Kod istenirse eksiksiz, çalıştırılabilir kod üret.")
        request.messages.forEach { message ->
            when (message.role) {
                MessageRole.SYSTEM -> append("SİSTEM: ")
                MessageRole.USER -> append("KULLANICI: ")
                MessageRole.ASSISTANT -> append("ASİSTAN: ")
            }
            appendLine(message.text)
        }
        request.attachments.forEach { attachment ->
            attachment.extractedText?.takeIf { it.isNotBlank() }?.let {
                appendLine("EK ${attachment.displayName}:\n$it")
            }
        }
        append("ASİSTAN:")
    }
}
