package com.unifiedai.app.feature.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.unifiedai.app.core.model.ChatAttachment
import com.unifiedai.app.core.model.ChatMode
import com.unifiedai.app.core.model.MessageRole

@Composable
fun ChatScreen(viewModel: ChatViewModel, contentPadding: PaddingValues) {
    val state by viewModel.state.collectAsState()
    val listState = rememberLazyListState()
    LaunchedEffect(state.messages.size, state.isGenerating) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
            .background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                ),
            ),
    ) {
        Header(mode = state.mode, onModeChange = viewModel::changeMode, onNewChat = viewModel::newConversation)

        if (state.messages.isEmpty()) {
            EmptyConversation(modifier = Modifier.weight(1f), mode = state.mode)
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(state.messages, key = { it.id }) { message -> MessageCard(message) }
                if (state.isGenerating) {
                    item("thinking") { ThinkingCard(state.generationStage ?: "Düşünüyor") }
                }
            }
        }

        AnimatedVisibility(state.error != null) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = state.error.orEmpty(),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f),
                    )
                    if (state.canRetry && !state.isGenerating) {
                        TextButton(onClick = viewModel::retry) { Text("Tekrar dene") }
                    }
                }
            }
        }
        Composer(
            value = state.input,
            attachments = state.attachments,
            generating = state.isGenerating,
            loadingAttachment = state.isLoadingAttachment,
            onValueChange = viewModel::setInput,
            onAttachmentSelected = viewModel::addAttachment,
            onRemoveAttachment = viewModel::removeAttachment,
            onSend = viewModel::send,
            onStop = viewModel::stop,
        )
    }
}

@Composable
private fun Header(mode: ChatMode, onModeChange: (ChatMode) -> Unit, onNewChat: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Birleşik AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Yerel öncelikli çoklu-model asistan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalIconButton(onClick = onNewChat) {
                Icon(Icons.Rounded.AddComment, contentDescription = "Yeni sohbet")
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ModeChip("Hızlı", ChatMode.FAST, mode, onModeChange)
            ModeChip("Akıllı", ChatMode.SMART, mode, onModeChange)
            ModeChip("Konsey", ChatMode.COUNCIL, mode, onModeChange)
            ModeChip("Yalnızca Yerel", ChatMode.LOCAL_ONLY, mode, onModeChange)
        }
    }
}

@Composable
private fun ModeChip(label: String, value: ChatMode, selected: ChatMode, onChange: (ChatMode) -> Unit) {
    FilterChip(
        selected = value == selected,
        onClick = { onChange(value) },
        label = { Text(label) },
    )
}

@Composable
private fun EmptyConversation(modifier: Modifier = Modifier, mode: ChatMode) {
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Card(
            modifier = Modifier.padding(24.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)),
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Tek soru, birden fazla güçlü bakış", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    when (mode) {
                        ChatMode.FAST -> "Tek uygun modelle en hızlı yanıtı alırsın."
                        ChatMode.SMART -> "Göreve en uygun model seçilir; gerekirse ikinci model cevabı eleştirir."
                        ChatMode.COUNCIL -> "En az üç model bağımsız düşünür, çelişkiler eleştirilir ve tek cevap sentezlenir."
                        ChatMode.LOCAL_ONLY -> "Sadece telefondaki yerel model ve varsa bağlı Ollama kullanılır; bulut çağrısı yapılmaz."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                HorizontalDivider()
                Text("Başlamak için Ayarlar → Telefon içi AI bölümünden ücretsiz yerel modeli indir. İstersen ayrıca PC Ollama veya bulut sağlayıcı bağlayabilirsin.", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun MessageCard(message: ChatMessageUi) {
    val isUser = message.role == MessageRole.USER
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.86f else 0.96f),
            shape = RoundedCornerShape(
                topStart = 22.dp,
                topEnd = 22.dp,
                bottomStart = if (isUser) 22.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 22.dp,
            ),
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
            tonalElevation = if (isUser) 0.dp else 2.dp,
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(message.text.ifBlank { "…" }, style = MaterialTheme.typography.bodyLarge)
                if (!isUser && (message.providerId != null || !message.completed)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (message.providerId != null) {
                            AssistChip(onClick = {}, label = { Text(message.providerId + (message.modelId?.let { " • $it" } ?: ""), maxLines = 1) })
                        }
                        if (!message.completed) {
                            Text("Tamamlanmadı", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThinkingCard(stage: String) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text(stage, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun Composer(
    value: String,
    attachments: List<ChatAttachment>,
    generating: Boolean,
    loadingAttachment: Boolean,
    onValueChange: (String) -> Unit,
    onAttachmentSelected: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
) {
    Surface(tonalElevation = 8.dp, shadowElevation = 10.dp) {
        Column(Modifier.fillMaxWidth()) {
            AnimatedVisibility(attachments.isNotEmpty() || loadingAttachment) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    attachments.forEach { attachment ->
                        InputChip(
                            selected = false,
                            onClick = {},
                            label = { Text(attachment.displayName, maxLines = 1) },
                            trailingIcon = {
                                IconButton(onClick = { onRemoveAttachment(attachment.id) }, enabled = !generating) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Eki kaldır", modifier = Modifier.size(16.dp))
                                }
                            },
                        )
                    }
                    if (loadingAttachment) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                AttachmentPickerButton(
                    enabled = !generating && !loadingAttachment && attachments.size < 4,
                    onSelected = onAttachmentSelected,
                )
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    enabled = !generating,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Bir şey sor…") },
                    minLines = 1,
                    maxLines = 6,
                    shape = RoundedCornerShape(22.dp),
                )
                FilledIconButton(
                    onClick = if (generating) onStop else onSend,
                    enabled = generating || value.isNotBlank() || attachments.isNotEmpty(),
                ) {
                    Icon(if (generating) Icons.Rounded.StopCircle else Icons.Rounded.Send, contentDescription = if (generating) "Durdur" else "Gönder")
                }
            }
        }
    }
}
