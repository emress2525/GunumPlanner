package com.unifiedai.app.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.unifiedai.app.data.repository.ProviderPolicy
import com.unifiedai.app.data.provider.ondevice.OnDeviceModelManager
import com.unifiedai.app.data.provider.ondevice.OnDeviceModelState

@Composable
fun SettingsScreen(viewModel: SettingsViewModel, contentPadding: PaddingValues) {
    val state by viewModel.state.collectAsState()
    Column(
        modifier = Modifier.fillMaxSize().padding(contentPadding).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ücretsiz temel artık telefon içi modeldir. İstersen PC'deki Ollama'yı ve bulut sağlayıcılarını ek güç olarak kullanabilirsin.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        OnDeviceModelCard(state, viewModel)
        OllamaCard(state, viewModel)

        SettingsToggleCard(
            title = "Bulut sağlayıcılarına izin ver",
            subtitle = "Kapalıyken Gemini, OpenAI, Claude ve DeepSeek hiç oluşturulmaz.",
            checked = state.settings.cloudAllowed,
            onChecked = viewModel::setCloudAllowed,
        )
        SettingsToggleCard(
            title = "Sohbet geçmişi",
            subtitle = "Yeni sohbetleri cihazda sakla.",
            checked = state.settings.historyEnabled,
            onChecked = viewModel::setHistoryEnabled,
        )
        SettingsToggleCard(
            title = "Uzun süreli hafıza",
            subtitle = "İlk sürümde kapalı kalır; açık olsa bile otomatik kişisel profil çıkarımı yapılmaz.",
            checked = state.settings.memoryEnabled,
            onChecked = viewModel::setMemoryEnabled,
        )

        Text("Bulut modelleri", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        ProviderCard("gemini", "Google Gemini", state.settings.gemini, "Ücretsiz geliştirici kotası uygun modellerde kullanılabilir.", "API anahtarı", "gemini" in state.savedSecrets, viewModel)
        ProviderCard("openai", "OpenAI", state.settings.openAi, "İsteğe bağlı ücretli API. Ücretsiz omurga için gerekli değildir.", "API anahtarı", "openai" in state.savedSecrets, viewModel)
        ProviderCard("anthropic", "Anthropic Claude", state.settings.anthropic, "İsteğe bağlı ücretli API. Konsey için ayrıca izin gerekir.", "API anahtarı", "anthropic" in state.savedSecrets, viewModel)
        ProviderCard("deepseek", "DeepSeek", state.settings.deepSeek, "İsteğe bağlı API; yerel DeepSeek modellerini Ollama üzerinden ücretsiz kullanabilirsin.", "API anahtarı", "deepseek" in state.savedSecrets, viewModel)

        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)) {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Rounded.Lock, contentDescription = null)
                Text("API anahtarları Android Keystore ile AES/GCM şifrelenir. Loglarda Authorization, x-api-key ve x-goog-api-key başlıkları maskelenir.", style = MaterialTheme.typography.bodySmall)
            }
        }

        if (state.error != null) {
            Text(state.error.orEmpty(), color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
    }
}


@Composable
private fun OnDeviceModelCard(state: SettingsUiState, viewModel: SettingsViewModel) {
    Card(shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Computer, contentDescription = null)
                Column(Modifier.weight(1f)) {
                    Text("Telefon içi AI • ${OnDeviceModelManager.MODEL_NAME}", fontWeight = FontWeight.SemiBold)
                    Text("İndirdikten sonra internetsiz çalışır. Model yaklaşık 2,6 GB; 8 GB RAM önerilir.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            when (val modelState = state.onDeviceModelState) {
                OnDeviceModelState.Missing -> {
                    Text("Model henüz telefonda değil.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = viewModel::downloadOnDeviceModel) { Text("Yerel modeli indir") }
                }
                is OnDeviceModelState.Downloading -> {
                    val progress = if (modelState.totalBytes > 0) modelState.downloadedBytes.toFloat() / modelState.totalBytes else 0f
                    LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text("İndiriliyor • %.1f / %.1f GB".format(modelState.downloadedBytes / 1_073_741_824.0, modelState.totalBytes / 1_073_741_824.0), style = MaterialTheme.typography.bodySmall)
                }
                OnDeviceModelState.Ready -> {
                    Text("Hazır • tamamen cihazda çalışabilir", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = viewModel::deleteOnDeviceModel) { Text("Modeli sil") }
                }
                is OnDeviceModelState.Error -> {
                    Text(modelState.message, color = MaterialTheme.colorScheme.error)
                    Button(onClick = viewModel::downloadOnDeviceModel) { Text("Tekrar indir") }
                }
            }
        }
    }
}

@Composable
private fun OllamaCard(state: SettingsUiState, viewModel: SettingsViewModel) {
    var url by remember(state.settings.ollamaUrl) { mutableStateOf(state.settings.ollamaUrl) }
    Card(shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Computer, contentDescription = null)
                Column {
                    Text("Ollama • isteğe bağlı PC modeli", fontWeight = FontWeight.SemiBold)
                    Text("Telefon ve bilgisayar aynı ağdaysa PC'deki modelleri ek olarak kullanır.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Ollama adresi") },
                supportingText = { Text("Gerçek telefonda örnek: http://192.168.1.50:11434/ • boş bırakabilirsin") },
                singleLine = true,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.setOllamaUrl(url) }) { Text("Kaydet") }
                OutlinedButton(onClick = { viewModel.setOllamaUrl(url); viewModel.testOllama() }) { Text("Bağlantıyı test et") }
            }
            if (state.ollamaStatus != null) Text(state.ollamaStatus, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            if (state.ollamaModels.isNotEmpty()) Text(state.ollamaModels.take(6).joinToString(" • ") { it.displayName }, style = MaterialTheme.typography.bodySmall)
            Text("Not: HTTP yerel ağ bağlantısı şifreli değildir. Hassas işler için yalnızca güvendiğin ağda kullan veya Ollama'yı HTTPS reverse proxy arkasına al.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsToggleCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun ProviderCard(
    id: String,
    title: String,
    policy: ProviderPolicy,
    subtitle: String,
    secretLabel: String,
    hasSecret: Boolean,
    viewModel: SettingsViewModel,
) {
    var key by remember(id) { mutableStateOf("") }
    var limitText by remember(policy.dailyRequestLimit) { mutableStateOf(policy.dailyRequestLimit.toString()) }
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Cloud, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = policy.enabled, onCheckedChange = { viewModel.setProviderPolicy(id, policy.copy(enabled = it)) })
            }
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                label = { Text(if (hasSecret) "$secretLabel • kayıtlı" else secretLabel) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.saveSecret(id, key); key = "" }, enabled = key.isNotBlank()) { Text("Anahtarı kaydet") }
                if (hasSecret) OutlinedButton(onClick = { viewModel.removeSecret(id) }) { Text("Sil") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = it.filter(Char::isDigit).take(5) },
                    modifier = Modifier.width(140.dp),
                    label = { Text("Günlük limit") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                )
                OutlinedButton(onClick = {
                    limitText.toIntOrNull()?.coerceIn(1, 10_000)?.let { viewModel.setProviderPolicy(id, policy.copy(dailyRequestLimit = it)) }
                }) { Text("Limiti kaydet") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = policy.allowInCouncil,
                    onCheckedChange = { viewModel.setProviderPolicy(id, policy.copy(allowInCouncil = it)) },
                )
                Text("Konsey modunda bu ücretli sağlayıcıya izin ver", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
