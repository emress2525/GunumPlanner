package com.unifiedai.app.domain.routing

import com.unifiedai.app.core.model.*

data class RoutingDecision(
    val taskClass: TaskClass,
    val selectedModels: List<ModelDescriptor>,
    val rationale: String,
)

class TaskRouter(private val classifier: TaskClassifier) {
    fun route(
        prompt: String,
        attachments: List<ChatAttachment>,
        mode: ChatMode,
        models: List<ModelDescriptor>,
        health: Map<String, ProviderHealth>,
        preferredModelKey: String? = null,
        excludedModelKeys: Set<String> = emptySet(),
    ): RoutingDecision {
        val task = classifier.classify(prompt, attachments)
        val required = requiredCapability(task)

        val eligible = models.asSequence()
            .filterNot { it.key in excludedModelKeys }
            .filter { health[it.key] !is ProviderHealth.Unhealthy }
            .filter { mode != ChatMode.LOCAL_ONLY || it.isLocal }
            .filter { required == null || required in it.capabilities }
            .toList()
            .ifEmpty {
                models.asSequence()
                    .filterNot { it.key in excludedModelKeys }
                    .filter { health[it.key] !is ProviderHealth.Unhealthy }
                    .filter { mode != ChatMode.LOCAL_ONLY || it.isLocal }
                    .filter { ModelCapability.CHAT in it.capabilities }
                    .toList()
            }

        require(eligible.isNotEmpty()) { "Kullanılabilir model yok. Ayarlar > Telefon içi AI bölümünden yerel modeli indir veya bir sağlayıcı bağla." }

        val ranked = eligible.sortedByDescending { score(it, task, preferredModelKey) }
        val selected = when (mode) {
            ChatMode.FAST, ChatMode.LOCAL_ONLY -> ranked.take(1)
            ChatMode.SMART -> ranked.take(2)
            ChatMode.COUNCIL -> {
                require(ranked.size >= 3) { "Konsey modu için en az 3 kullanılabilir model gerekli." }
                ranked.take(4)
            }
        }

        val rationale = buildString {
            append("task=").append(task)
            append("; mode=").append(mode)
            append("; selected=").append(selected.joinToString { it.key })
            if (preferredModelKey != null && selected.none { it.key == preferredModelKey }) {
                append("; preferred unavailable/ineligible, fallback used")
            }
        }
        return RoutingDecision(task, selected, rationale)
    }

    private fun requiredCapability(task: TaskClass): ModelCapability? = when (task) {
        TaskClass.CODING -> ModelCapability.CODING
        TaskClass.REASONING -> ModelCapability.REASONING
        TaskClass.VISION -> ModelCapability.VISION
        TaskClass.RESEARCH, TaskClass.SUMMARY, TaskClass.TRANSLATION,
        TaskClass.DOCUMENT_ANALYSIS, TaskClass.CREATIVE_WRITING, TaskClass.GENERAL_CHAT -> ModelCapability.CHAT
    }

    private fun score(model: ModelDescriptor, task: TaskClass, preferredModelKey: String?): Int {
        var score = 0
        if (model.key == preferredModelKey) score += 10_000
        if (ModelCapability.CHAT in model.capabilities) score += 100
        when (task) {
            TaskClass.CODING -> if (ModelCapability.CODING in model.capabilities) score += 1_000
            TaskClass.REASONING -> if (ModelCapability.REASONING in model.capabilities) score += 1_000
            TaskClass.VISION -> if (ModelCapability.VISION in model.capabilities) score += 1_000
            else -> Unit
        }
        score += when (model.latencyClass) {
            LatencyClass.FAST -> 30
            LatencyClass.MEDIUM -> 15
            LatencyClass.SLOW -> 0
        }
        if (model.isLocal) score += 10
        score += model.privacyClass
        score -= model.costClass * 5
        return score
    }
}
