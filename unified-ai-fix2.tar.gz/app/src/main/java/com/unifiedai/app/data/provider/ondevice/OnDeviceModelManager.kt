package com.unifiedai.app.data.provider.ondevice

import android.content.Context
import android.os.StatFs
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

sealed interface OnDeviceModelState {
    data object Missing : OnDeviceModelState
    data class Downloading(val downloadedBytes: Long, val totalBytes: Long) : OnDeviceModelState
    data object Ready : OnDeviceModelState
    data class Error(val message: String) : OnDeviceModelState
}

class OnDeviceModelManager(
    context: Context,
    private val httpClient: OkHttpClient,
) : OnDeviceRuntime {
    private val appContext = context.applicationContext
    private val modelDir = File(appContext.filesDir, "models").apply { mkdirs() }
    private val modelFile = File(modelDir, MODEL_FILE)
    private val partialFile = File(modelDir, "$MODEL_FILE.part")
    private val mutableState = MutableStateFlow<OnDeviceModelState>(if (isValidModelFile()) OnDeviceModelState.Ready else OnDeviceModelState.Missing)
    val state = mutableState.asStateFlow()

    private val engineMutex = Mutex()
    @Volatile private var engine: Engine? = null

    override val ready: Boolean get() = isValidModelFile()

    suspend fun download() = withContext(Dispatchers.IO) {
        if (ready) {
            mutableState.value = OnDeviceModelState.Ready
            return@withContext
        }
        val available = StatFs(appContext.filesDir.absolutePath).availableBytes
        require(available >= REQUIRED_FREE_BYTES) { "Yerel model için en az 4 GB boş alan gerekli." }

        val request = Request.Builder().url(MODEL_URL).build()
        runCatching {
            httpClient.newCall(request).execute().use { response ->
                require(response.isSuccessful) { "Model indirilemedi: HTTP ${response.code}" }
                val body = response.body
                val total = body.contentLength().takeIf { it > 0 } ?: MODEL_SIZE_BYTES
                var downloaded = 0L
                var lastReported = 0L
                partialFile.outputStream().buffered().use { output ->
                    body.byteStream().buffered().use { input ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 8)
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            if (downloaded - lastReported >= 4L * 1024 * 1024 || downloaded == total) {
                                lastReported = downloaded
                                mutableState.value = OnDeviceModelState.Downloading(downloaded, total)
                            }
                        }
                    }
                }
                require(partialFile.length() >= MODEL_SIZE_BYTES) { "Model dosyası eksik indi (${partialFile.length()} bayt)." }
                if (modelFile.exists()) modelFile.delete()
                require(partialFile.renameTo(modelFile)) { "Model dosyası kaydedilemedi." }
                mutableState.value = OnDeviceModelState.Ready
            }
        }.onFailure { t ->
            partialFile.delete()
            mutableState.value = OnDeviceModelState.Error(t.message ?: "Model indirilemedi")
            throw t
        }
    }

    suspend fun deleteModel() = withContext(Dispatchers.IO) {
        engineMutex.withLock {
            runCatching { engine?.close() }
            engine = null
        }
        partialFile.delete()
        modelFile.delete()
        mutableState.value = OnDeviceModelState.Missing
    }

    override suspend fun generate(prompt: String): String = withContext(Dispatchers.Default) {
        ensureEngine().createConversation().use { conversation ->
            conversation.sendMessage(prompt).contents.toString()
        }
    }

    override fun stream(prompt: String): Flow<String> = flow {
        val active = ensureEngine()
        active.createConversation().use { conversation ->
            conversation.sendMessageAsync(prompt).collect { message ->
                val text = message.contents.toString()
                if (text.isNotEmpty()) emit(text)
            }
        }
    }.flowOn(Dispatchers.Default)

    override suspend fun cancel() {
        // LiteRT-LM Flow cancellation is propagated by coroutine cancellation.
    }

    private suspend fun ensureEngine(): Engine = engineMutex.withLock {
        engine?.let { return@withLock it }
        require(ready) { "Telefon içi model henüz indirilmedi" }
        val config = EngineConfig(
            modelPath = modelFile.absolutePath,
            backend = Backend.CPU(),
            cacheDir = appContext.cacheDir.absolutePath,
        )
        Engine(config).also {
            it.initialize()
            engine = it
        }
    }

    private fun isValidModelFile(): Boolean = modelFile.isFile && modelFile.length() >= MODEL_SIZE_BYTES

    companion object {
        const val MODEL_NAME = "Gemma 4 E2B"
        const val MODEL_FILE = "gemma-4-E2B-it.litertlm"
        const val MODEL_SIZE_BYTES = 2_588_147_712L
        const val REQUIRED_FREE_BYTES = 4L * 1024 * 1024 * 1024
        const val MODEL_URL = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm?download=true"
    }
}
