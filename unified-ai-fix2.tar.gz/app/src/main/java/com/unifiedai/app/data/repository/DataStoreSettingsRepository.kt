package com.unifiedai.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.unifiedai.app.core.model.ChatMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

class DataStoreSettingsRepository(private val context: Context) : SettingsRepository {
    private object Keys {
        val ollamaUrl = stringPreferencesKey("ollama_url")
        val mode = stringPreferencesKey("default_mode")
        val history = booleanPreferencesKey("history_enabled")
        val memory = booleanPreferencesKey("memory_enabled")
        val cloud = booleanPreferencesKey("cloud_allowed")
        fun enabled(id: String) = booleanPreferencesKey("provider_${id}_enabled")
        fun limit(id: String) = intPreferencesKey("provider_${id}_daily_limit")
        fun council(id: String) = booleanPreferencesKey("provider_${id}_council")
    }

    override val settings: Flow<AppSettings> = context.settingsDataStore.data.map(::mapSettings)
    override suspend fun current(): AppSettings = settings.first()

    override suspend fun setOllamaUrl(url: String) {
        val normalized = normalizeUrl(url)
        context.settingsDataStore.edit { it[Keys.ollamaUrl] = normalized }
    }

    override suspend fun setDefaultMode(mode: ChatMode) { context.settingsDataStore.edit { it[Keys.mode] = mode.name } }
    override suspend fun setHistoryEnabled(enabled: Boolean) { context.settingsDataStore.edit { it[Keys.history] = enabled } }
    override suspend fun setMemoryEnabled(enabled: Boolean) { context.settingsDataStore.edit { it[Keys.memory] = enabled } }
    override suspend fun setCloudAllowed(enabled: Boolean) { context.settingsDataStore.edit { it[Keys.cloud] = enabled } }

    override suspend fun setProviderPolicy(providerId: String, policy: ProviderPolicy) {
        require(policy.dailyRequestLimit in 1..10_000)
        context.settingsDataStore.edit {
            it[Keys.enabled(providerId)] = policy.enabled
            it[Keys.limit(providerId)] = policy.dailyRequestLimit
            it[Keys.council(providerId)] = policy.allowInCouncil
        }
    }

    private fun mapSettings(prefs: Preferences): AppSettings = AppSettings(
        ollamaUrl = prefs[Keys.ollamaUrl] ?: "",
        defaultMode = prefs[Keys.mode]?.let { runCatching { ChatMode.valueOf(it) }.getOrNull() } ?: ChatMode.SMART,
        historyEnabled = prefs[Keys.history] ?: true,
        memoryEnabled = prefs[Keys.memory] ?: false,
        cloudAllowed = prefs[Keys.cloud] ?: true,
        gemini = policy(prefs, "gemini"),
        openAi = policy(prefs, "openai"),
        anthropic = policy(prefs, "anthropic"),
        deepSeek = policy(prefs, "deepseek"),
    )

    private fun policy(prefs: Preferences, id: String) = ProviderPolicy(
        enabled = prefs[Keys.enabled(id)] ?: false,
        dailyRequestLimit = prefs[Keys.limit(id)] ?: 25,
        allowInCouncil = prefs[Keys.council(id)] ?: false,
    )

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        require(trimmed.startsWith("http://") || trimmed.startsWith("https://")) { "URL http:// veya https:// ile başlamalı" }
        return if (trimmed.endsWith('/')) trimmed else "$trimmed/"
    }
}
