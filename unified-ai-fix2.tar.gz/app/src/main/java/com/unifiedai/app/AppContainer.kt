package com.unifiedai.app

import android.content.Context
import androidx.room.Room
import com.unifiedai.app.core.database.AppDatabase
import com.unifiedai.app.core.network.HttpClientFactory
import com.unifiedai.app.core.security.AndroidKeystoreSecretStore
import com.unifiedai.app.data.provider.cloud.ProviderFactory
import com.unifiedai.app.data.provider.ondevice.OnDeviceModelManager
import com.unifiedai.app.data.provider.ondevice.OnDeviceProvider
import com.unifiedai.app.data.repository.*
import com.unifiedai.app.domain.chat.ChatEngine
import com.unifiedai.app.domain.chat.ChatRepository
import com.unifiedai.app.domain.chat.DynamicChatEngine

class AppContainer(context: Context) {
    val database: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "unified-ai.db",
    ).build()

    val chatRepository: ChatRepository = RoomChatRepository(database.chatDao())
    val attachmentLoader: AttachmentLoader = AttachmentRepository(context.applicationContext)
    val settingsRepository: SettingsRepository = DataStoreSettingsRepository(context.applicationContext)
    val secretStore = AndroidKeystoreSecretStore(context.applicationContext)
    val usageRepository = ProviderUsageRepository(context.applicationContext)
    val httpClient = HttpClientFactory.create()
    val onDeviceModelManager = OnDeviceModelManager(context.applicationContext, httpClient)
    val onDeviceProvider = OnDeviceProvider(onDeviceModelManager)
    val providerFactory = ProviderFactory(settingsRepository, secretStore, usageRepository, httpClient, onDeviceProvider)
    val chatEngine: ChatEngine = DynamicChatEngine(providerFactory)
}
