package com.unifiedai.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.unifiedai.app.feature.chat.ChatViewModel
import com.unifiedai.app.feature.history.HistoryViewModel
import com.unifiedai.app.feature.settings.SettingsViewModel

class ChatViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        ChatViewModel(container.chatEngine, container.chatRepository, container.settingsRepository, container.attachmentLoader) as T
}

class HistoryViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = HistoryViewModel(container.chatRepository) as T
}

class SettingsViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = SettingsViewModel(container.settingsRepository, container.secretStore, container.onDeviceModelManager) as T
}
