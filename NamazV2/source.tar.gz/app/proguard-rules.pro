# Namaz V2 currently uses platform APIs and no reflection-heavy libraries.
