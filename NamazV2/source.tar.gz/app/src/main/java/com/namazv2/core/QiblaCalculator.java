package com.namazv2.core;

public final class QiblaCalculator {
    private static final double KAABA_LAT = 21.4225;
    private static final double KAABA_LON = 39.8262;
    private QiblaCalculator() {}

    public static double bearingToKaaba(double latitude, double longitude) {
        double lat1 = Math.toRadians(latitude);
        double lat2 = Math.toRadians(KAABA_LAT);
        double dLon = Math.toRadians(KAABA_LON - longitude);
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        double deg = Math.toDegrees(Math.atan2(y, x));
        deg %= 360.0;
        return deg < 0 ? deg + 360.0 : deg;
    }
}
