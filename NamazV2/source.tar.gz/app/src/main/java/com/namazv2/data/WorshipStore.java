package com.namazv2.data;

import android.content.Context;
import android.content.SharedPreferences;
import java.time.LocalDate;

public final class WorshipStore {
    private static final String PREFS = "worship_store";
    private final SharedPreferences prefs;
    public WorshipStore(Context context) { prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public boolean isDone(LocalDate date, String prayer) { return prefs.getBoolean(key(date, prayer), false); }
    public void setDone(LocalDate date, String prayer, boolean done) { prefs.edit().putBoolean(key(date, prayer), done).apply(); }
    public int completedCount(LocalDate date) {
        int n = 0; for (String p : prayers()) if (isDone(date, p)) n++; return n;
    }
    public int sevenDayCompleted() {
        int n = 0; LocalDate d = LocalDate.now();
        for (int i = 0; i < 7; i++) { n += completedCount(d.minusDays(i)); }
        return n;
    }
    public int currentPerfectStreak() {
        int streak = 0; LocalDate d = LocalDate.now();
        if (completedCount(d) < 5) d = d.minusDays(1);
        for (int i = 0; i < 365; i++) {
            if (completedCount(d.minusDays(i)) == 5) streak++; else break;
        }
        return streak;
    }
    public String getNote(LocalDate date) { return prefs.getString("note:" + date, ""); }
    public void setNote(LocalDate date, String note) { prefs.edit().putString("note:" + date, note == null ? "" : note).apply(); }
    public static String[] prayers() { return new String[]{"Sabah","Öğle","İkindi","Akşam","Yatsı"}; }
    private static String key(LocalDate d, String p) { return "pray:" + d + ":" + p; }
}
