package com.namazv2.core;

import org.junit.Test;
import java.time.LocalDate;
import java.util.Map;
import static org.junit.Assert.*;

public class CoreLogicTest {
    @Test public void ankaraPrayerTimesAreFiniteAndOrderedEnoughForUi() {
        PrayerTimesCalculator c = new PrayerTimesCalculator(18.0, 17.0);
        Map<String, Double> p = c.calculate(LocalDate.of(2026, 9, 15), 39.9334, 32.8597, 3.0, 1);
        assertEquals(6, p.size());
        for (double v : p.values()) assertTrue(Double.isFinite(v));
        assertTrue(p.get("İmsak") < p.get("Güneş"));
        assertTrue(p.get("Güneş") < p.get("Öğle"));
        assertTrue(p.get("Öğle") < p.get("İkindi"));
        assertTrue(p.get("İkindi") < p.get("Akşam"));
        assertTrue(p.get("Akşam") < p.get("Yatsı"));
    }

    @Test public void qiblaBearingIsNormalized() {
        double q = QiblaCalculator.bearingToKaaba(39.9334, 32.8597);
        assertTrue(q >= 0 && q < 360);
        assertTrue(q > 140 && q < 180);
    }

    @Test public void contentSearchFindsTurkishDiacriticsAndEmptyIsSafe() {
        assertFalse(ContentCatalog.search("abdest").isEmpty());
        assertFalse(ContentCatalog.search("siyer").isEmpty());
        assertTrue(ContentCatalog.search("no_such_topic_123").isEmpty());
    }
}
