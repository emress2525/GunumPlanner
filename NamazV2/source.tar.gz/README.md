# Namaz V2

Android 8+ (API 26+) için namaz vakitleri, ezan alarmı, Kur'an okuma, ibadet takibi, kıble, siyer, temel dini bilgiler, dua/zikir ve kaynak portalını tek uygulamada birleştiren yerel-öncelikli uygulama.

## Bu build'de çalışanlar
- Cihaz konumu veya açıkça etiketlenmiş İstanbul varsayılanıyla çevrimdışı astronomik namaz vakti hesabı.
- Android AlarmManager ile uygulama kapalıyken namaz vakti bildirimi; exact alarm izni yoksa inexact fallback.
- Kullanıcının seçtiği yerel ses dosyasını ezan vakti foreground media service ile çalma.
- Günlük 5 vakit işaretleme, 7 günlük ilerleme, tam-gün serisi ve cihazda saklanan not.
- Tanzil Project Uthmani Arapça Kur'an metni (CC BY 3.0), 114 sure okuyucu.
- Kıble açısı ve rotation-vector sensörü varsa canlı pusula.
- Kaynak notlu özgün temel İslam/ibadet/ahlak/siyer içerikleri.
- Uygulama içi kaynak tarayıcısı: Diyanet, Quran.com, Tanzil.
- Premium ekranı ve ticari ürün sınırları; bu test APK'sı gerçek ödeme çekmez.

## Güven / telif
Kur'an metni Tanzil Project'ten değiştirilmeden dağıtılır ve uygulama içinde kaynak/lisans belirtilir. Diyanet'in meal, tefsir ve kitap tam metinleri ticari lisans alınmadan APK içine kopyalanmaz; ilgili resmi sayfalar uygulama içi tarayıcıda açılır. Uygulamadaki özgün özetler fetva yerine geçmez.

## Build
Gereksinimler: JDK 17, Gradle 8.13, Android SDK 36.

```bash
gradle testDebugUnitTest
gradle lintDebug
gradle assembleDebug
```

GitHub Actions build'i Tanzil Kur'an varlığını sabit upstream commit'ten `app/src/main/assets/quran-uthmani.txt` konumuna indirir ve 6200+ satır doğrulaması yapar.
